<?php
/**
 * Plugin Name: Cart Abandonment Recovery YZC
 * Description: Recover your lost revenue. Capture email address and mobile number of users on the checkout page and send follow up emails and sms and whatsapp message if they don't complete the purchase.
 * Version: 1.2.13
 * Author: DoubleTick Inc
 * Author URI: http://www.doubletick.net/woo-cart-abandonment-recovery-yzc
 * Text Domain: cart-abandonment-recovery-yzc
 * WC requires at least: 3.0
 * WC tested up to: 5.5.0
 *
 * @package Cart-Abandonment-Recovery-Yzc
 */

/**
 * Set constants.
 */
define('CARTFLOWS_CA_FILE', __FILE__);

/**
 * Loader
 */
require_once 'classes/class-cartflows-ca-loader.php';
