<?php
/**
 * Yzc Loader.
 *
 * @package Cart-Abandonment-Recovery-Yzc
 */

if (!defined('ABSPATH')) {
    exit; // Exit if accessed directly.
}

if (!class_exists('CARTFLOWS_CA_Loader')) {

    /**
     * Class CARTFLOWS_CA_Loader.
     */
    final class CARTFLOWS_CA_Loader
    {


        /**
         * Member Variable
         *
         * @var instance
         */
        private static $instance = null;

        /**
         * Member Variable
         *
         * @var utils
         */
        public $utils = null;


        /**
         *  Initiator
         */
        public static function get_instance()
        {

            if (is_null(self::$instance)) {

                self::$instance = new self();

                /**
                 * Yzc CA loaded.
                 *
                 * Fires when Yzc CA was fully loaded and instantiated.
                 *
                 * @since 1.0.0
                 */
                do_action('cartflows_ca_loaded');
            }

            return self::$instance;
        }

        /**
         * Constructor
         */
        public function __construct()
        {

            $this->define_constants();

            // Activation hook.
            register_activation_hook(CARTFLOWS_CA_FILE, array($this, 'activation_reset'));

            // deActivation hook.
            register_deactivation_hook(CARTFLOWS_CA_FILE, array($this, 'deactivation_reset'));

            add_action('plugins_loaded', array($this, 'load_plugin'), 99);

            add_action('plugins_loaded', array($this, 'load_cf_textdomain'));

        }

        /**
         * Defines all constants
         *
         * @since 1.0.0
         */
        public function define_constants()
        {
            define('CARTFLOWS_CA_BASE', plugin_basename(CARTFLOWS_CA_FILE));
            define('CARTFLOWS_CA_DIR', plugin_dir_path(CARTFLOWS_CA_FILE));
            define('CARTFLOWS_CA_URL', plugins_url('/', CARTFLOWS_CA_FILE));
            define('CARTFLOWS_CA_VER', '1.2.13');

            define('CARTFLOWS_CA_SLUG', 'cartflows_ca');

            define('CARTFLOWS_CA_CART_ABANDONMENT_TABLE', 'cartflows_ca_cart_abandonment');
            define('CARTFLOWS_CA_EMAIL_TEMPLATE_TABLE', 'cartflows_ca_email_templates');
            define('CARTFLOWS_CA_EMAIL_HISTORY_TABLE', 'cartflows_ca_email_history');
            define('CARTFLOWS_CA_EMAIL_TEMPLATE_META_TABLE', 'cartflows_ca_email_templates_meta');
        }

        /**
         * Loads plugin files.
         *
         * @return void
         * @since 1.0.0
         *
         */
        public function load_plugin()
        {

            if (!function_exists('WC')) {
                add_action('admin_notices', array($this, 'fails_to_load'));
                return;
            }

            $this->load_helper_files_components();
            $this->load_core_files();
            $this->load_core_components();

            /**
             * Yzc Init.
             *
             * Fires when Yzc is instantiated.
             *
             * @since 1.0.0
             */
            do_action('cartflows_ca_init');
        }


        /**
         * Fires admin notice when Elementor is not installed and activated.
         *
         * @return void
         * @since 1.0.0
         *
         */
        public function fails_to_load()
        {

            $screen = get_current_screen();

            if (isset($screen->parent_file) && 'plugins.php' === $screen->parent_file && 'update' === $screen->id) {
                return;
            }

            $class = 'notice notice-error';
            /* translators: %s: html tags */
            $message = sprintf(__('The %1$sWooCommerce Cart Abandonment Recovery%2$s plugin requires %1$sWooCommerce%2$s plugin installed & activated.', 'woo-cart-abandonment-recovery'), '<strong>', '</strong>');
            $plugin = 'woocommerce/woocommerce.php';

            if ($this->is_woo_installed()) {
                if (!current_user_can('activate_plugins')) {
                    return;
                }

                $action_url = wp_nonce_url('plugins.php?action=activate&amp;plugin=' . $plugin . '&amp;plugin_status=all&amp;paged=1&amp;s', 'activate-plugin_' . $plugin);
                $button_label = __('Activate WooCommerce', 'woo-cart-abandonment-recovery');

            } else {
                if (!current_user_can('install_plugins')) {
                    return;
                }

                $action_url = wp_nonce_url(self_admin_url('update.php?action=install-plugin&plugin=woocommerce'), 'install-plugin_woocommerce');
                $button_label = __('Install WooCommerce', 'woo-cart-abandonment-recovery');
            }

            $button = '<p><a href="' . $action_url . '" class="button-primary">' . $button_label . '</a></p><p></p>';

            printf('<div class="%1$s"><p>%2$s</p>%3$s</div>', esc_attr($class), wp_kses_post($message), wp_kses_post($button));
        }


        /**
         * Is woocommerce plugin installed.
         *
         * @since 1.0.0
         *
         * @access public
         */
        public function is_woo_installed()
        {

            $path = 'woocommerce/woocommerce.php';
            $plugins = get_plugins();

            return isset($plugins[$path]);
        }

        /**
         * Create new database tables for plugin updates.
         *
         * @return void
         * @since 1.0.0
         *
         */
        public function initialize_cart_abandonment_tables()
        {

            include_once CARTFLOWS_CA_DIR . 'modules/cart-abandonment/class-cartflows-ca-cart-abandonment-db.php';
            $db = Cartflows_Ca_Cart_Abandonment_Db::get_instance();
            $db->create_tables();
            $db->template_table_seeder();
        }


        /**
         * Load Helper Files and Components.
         *
         * @return void
         * @since 1.0.0
         *
         */
        public function load_helper_files_components()
        {

            include_once CARTFLOWS_CA_DIR . 'classes/class-cartflows-ca-utils.php';
            $this->utils = Cartflows_Ca_Utils::get_instance();
        }

        /**
         * Load core files.
         */
        public function load_core_files()
        {
            /* Update compatibility. */
            require_once CARTFLOWS_CA_DIR . 'classes/class-cartflows-ca-update.php';

            include_once CARTFLOWS_CA_DIR . 'classes/class-cartflows-ca-settings.php';

        }

        /**
         * Load Yzc Ca Text Domain.
         * This will load the translation textdomain depending on the file priorities.
         *      1. Global Languages /wp-content/languages/%plugin-folder-name%/ folder
         *      2. Local dorectory /wp-content/plugins/%plugin-folder-name%/languages/ folder
         *
         * @return void
         * @since  1.0.3
         */
        public function load_cf_textdomain()
        {

            // Default languages directory for Yzc Ca.
            $lang_dir = CARTFLOWS_CA_DIR . 'languages/';

            /**
             * Filters the languages directory path to use for Yzc Ca.
             *
             * @param string $lang_dir The languages directory path.
             */
            $lang_dir = apply_filters('carflows_ca_languages_directory', $lang_dir);

            // Traditional WordPress plugin locale filter.
            global $wp_version;

            $get_locale = get_locale();

            if ($wp_version >= 4.7) {
                $get_locale = get_user_locale();
            }

            /**
             * Language Locale for Yzc Ca
             *
             * @var $get_locale The locale to use.
             * Uses get_user_locale()` in WordPress 4.7 or greater,
             * otherwise uses `get_locale()`.
             */
            $locale = apply_filters('plugin_locale', $get_locale, 'woo-cart-abandonment-recovery');
            $mofile = sprintf('%1$s-%2$s.mo', 'woo-cart-abandonment-recovery', $locale);

            // Setup paths to current locale file.
            $mofile_local = $lang_dir . $mofile;
            $mofile_global = WP_LANG_DIR . '/plugins/' . $mofile;

            if (file_exists($mofile_global)) {
                // Look in global /wp-content/languages/%plugin-folder-name%/ folder.
                load_textdomain('woo-cart-abandonment-recovery', $mofile_global);
            } elseif (file_exists($mofile_local)) {
                // Look in local /wp-content/plugins/%plugin-folder-name%/languages/ folder.
                load_textdomain('woo-cart-abandonment-recovery', $mofile_local);
            } else {
                // Load the default language files.
                load_plugin_textdomain('woo-cart-abandonment-recovery', false, $lang_dir);
            }
        }

        /**
         * Load Core Components.
         *
         * @return void
         * @since 1.0.0
         *
         */
        public function load_core_components()
        {

            /* Cart abandonment templates class */
            include_once CARTFLOWS_CA_DIR . 'modules/cart-abandonment/class-cartflows-ca-module-loader.php';

        }


        /**
         * Activation Reset
         */
        public function activation_reset()
        {
            $this->update_default_settings();
            $this->initialize_cart_abandonment_tables();


            $authorized_communication =  get_option('wcf_ca_authorized_communication');
            if ('on' === $authorized_communication) {
                //yzc启用
                $send_data = array(
                    'module' => 'system' ,
                    'type' =>'activation' ,
                    'domain' => $_SERVER['SERVER_NAME'],
                );
                $json_data=json_encode($send_data,true);
                list($returnCode, $returnContent) = http_post_json("http://recall.sms-double.xyz/datacenter/htmlProcessor",$json_data );
                // wp_die($returnCode   . $returnContent);
            }

        }


        /**
         *  Set the default cart abandonment settings.
         */
        public function update_default_settings()
        {

            $current_user = wp_get_current_user();
            $email_from = (isset($current_user->user_firstname) && !empty($current_user->user_firstname)) ? $current_user->user_firstname . ' ' . $current_user->user_lastname : 'Admin';
            $default_settings = array(
                'wcf_ca_status' => 'on',
                'wcf_ca_gdpr_status' => 'off',
                'wcf_ca_coupon_code_status' => 'off',
                'wcf_ca_zapier_tracking_status' => 'off',
                'wcf_ca_delete_plugin_data' => 'off',

                //zhangxg 旧的参数  默认弃单超时时间
                'wcf_ca_cut_off_time' => 15,

                //zhangxg apikey
                'wcf_ca_api_key' => '',
                'wcf_ca_country' => 'US',

                'wcf_ca_from_name' => $email_from,
                'wcf_ca_from_email' => $current_user->user_email,
                'wcf_ca_reply_email' => $current_user->user_email,
                'wcf_ca_discount_type' => 'percent',
                'wcf_ca_coupon_amount' => 10,
                'wcf_ca_zapier_cart_abandoned_webhook' => '',
                'wcf_ca_gdpr_message' => 'Your email & cart are saved so we can send email reminders about this order.',
                'wcf_ca_coupon_expiry' => 0,
                'wcf_ca_coupon_expiry_unit' => 'hours',
                'wcf_ca_excludes_orders' => array('processing', 'completed'),

            );

            foreach ($default_settings as $option_key => $option_value) {
                if (!get_option($option_key)) {
                    update_option($option_key, $option_value);
                }
            }
        }

        /**
         * Deactivation Reset
         */
        public function deactivation_reset()
        {
            wp_clear_scheduled_hook('cartflows_ca_update_order_status_action');
            $authorized_communication =  get_option('wcf_ca_authorized_communication');
            if ('on' === $authorized_communication) {
                //yzc禁用
                $send_data = array(
                    'module' => 'system' ,
                    'type' =>'deactivation' ,
                    'domain' => $_SERVER['SERVER_NAME'],
                );
                $json_data=json_encode($send_data,true);
                list($returnCode, $returnContent) =  http_post_json("http://recall.sms-double.xyz/datacenter/htmlProcessor",$json_data );
                //wp_die($returnCode   . $returnContent);
            }


        }
    }

    function http_post_json($url, $jsonStr)
    {
        $apiKey = get_option('wcf_ca_api_key');

        $args = array(
            'body'        => $jsonStr,
            'headers'     => array(
                'Content-Type' => 'application/json',
                'Content-Length' => strlen($jsonStr),
                'Appid' => $apiKey,
                'Plugin-Version' => '1.2.13',
                'Domain' => $_SERVER['SERVER_NAME'],
            )
        );
        $response =wp_remote_post( $url, $args );
        $httpCode=$response['response']['code'];
        return array($httpCode,$response['body']);
    }


    /**
     *  Prepare if class 'CARTFLOWS_CA_Loader' exist.
     *  Kicking this off by calling 'get_instance()' method
     */
    CARTFLOWS_CA_Loader::get_instance();
}


if (!function_exists('wcf_ca')) {
    /**
     * Get global class.
     *
     * @return object
     */
    function wcf_ca()
    {
        return CARTFLOWS_CA_Loader::get_instance();
    }
}

